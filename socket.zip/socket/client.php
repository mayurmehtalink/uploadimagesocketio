
<?php
$host    = "127.0.0.1";
$port    = 8000;
error_reporting(0) ;
$image = $_FILES["fileToUpload"]["tmp_name"];
$type = pathinfo($image, PATHINFO_EXTENSION);
$data = file_get_contents($image);
 $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
$socket_create = socket_create(AF_INET, SOCK_STREAM, 0) ;

$socket_connect = socket_connect($socket, $host, $port); 
if ($result === false) {
    $errorcode = socket_last_error();
    $errormsg = socket_strerror($errorcode);
    
    die("Couldn't create socket: [$errorcode] $errormsg -> start server.php file or do command php -q server.php on root file");
} 
socket_write($socket_connect, $base64, strlen($base64));
$result = socket_read ($socket_create, 1024);
echo 'Uploaded Succesfully';
socket_close($socket);
?>