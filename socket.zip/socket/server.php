<?php 
error_reporting(0) ;
$host = "127.0.0.1";
$port = 8000;
set_time_limit(0);
$socket_create = socket_create(AF_INET, SOCK_STREAM, 0) ;
$result = socket_bind($socket_create, $host, $port) ;
$result = socket_listen($socket_create, 3);
$child_process = socket_accept($socket_create) ;
$input = socket_read($child_process, 1024) ;
$img = str_replace('data:image/png;base64,', '', $input);
file_put_contents('upload/img'.rand(0,1000).'.png', base64_decode($img));
socket_write($child_process, $input, strlen ($input)) ;
socket_close($child_process);
socket_close($socket_create);
?>